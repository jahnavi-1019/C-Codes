#include <stdio.h>
int main() {
int n,i=165;
while(i>0){
n=i%10;
printf("%d ",n);
i=i/10;
}
}
